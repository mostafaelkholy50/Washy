<?php

return [
    'home' => 'الرئيسية',
    'about' => 'من نحن',
    'services' => 'خدماتنا',
    'portfolio' => 'معرض اعمالنا',
    'blog' => 'المدونة',
    'contact' => 'اتصل بنا',
];
