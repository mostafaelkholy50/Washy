

<?php $__env->startSection('title', 'تعديل المستخدم'); ?>

<?php $__env->startSection('content'); ?>
<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">تعديل المستخدم</h3>
    </div>
    <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="card-body">
            <div class="form-group mb-3">
                <label for="name">الاسم</label>
                <input type="text" name="name" class="form-control" id="name" value="<?php echo e($user->name); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="email">البريد الإلكتروني</label>
                <input type="email" name="email" class="form-control" id="email" value="<?php echo e($user->email); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="password">كلمة المرور (اتركها فارغة إذا لم ترد التغيير)</label>
                <input type="password" name="password" class="form-control" id="password">
            </div>
             <div class="form-group mb-3">
                <label for="password_confirmation">تأكيد كلمة المرور</label>
                <input type="password" name="password_confirmation" class="form-control" id="password_confirmation">
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary">تحديث</button>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-default float-end">إلغاء</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\vipp\Admin dashboard\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>