

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-3 col-6">
        <div class="small-box text-bg-primary">
            <div class="inner">
                <h3><?php echo e($counts['users']); ?></h3>
                <p>Users</p>
            </div>
            <div class="small-box-icon">
                <i class="bi bi-person-badge"></i>
            </div>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">
                More info <i class="bi bi-link-45deg"></i>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box text-bg-success">
            <div class="inner">
                <h3><?php echo e($counts['members']); ?></h3>
                <p>Members</p>
            </div>
            <div class="small-box-icon">
                <i class="bi bi-people"></i>
            </div>
            <a href="<?php echo e(route('admin.members.index')); ?>" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">
                More info <i class="bi bi-link-45deg"></i>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box text-bg-warning">
            <div class="inner">
                <h3><?php echo e($counts['posts']); ?></h3>
                <p>Posts</p>
            </div>
            <div class="small-box-icon">
                <i class="bi bi-journal-text"></i>
            </div>
            <a href="<?php echo e(route('admin.posts.index')); ?>" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">
                More info <i class="bi bi-link-45deg"></i>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box text-bg-danger">
            <div class="inner">
                <h3><?php echo e($counts['portfolios']); ?></h3>
                <p>Portfolios</p>
            </div>
            <div class="small-box-icon">
                <i class="bi bi-briefcase"></i>
            </div>
            <a href="<?php echo e(route('admin.portfolios.index')); ?>" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">
                More info <i class="bi bi-link-45deg"></i>
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\vipp\Admin dashboard\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>