<x-filament-panels::page.simple>
    {{-- Custom AdminLTE Login Page --}}
    <div class="login-box" style="width: 400px; margin: 7% auto;">
        <div class="card card-outline card-primary" style="border-radius: 1rem; box-shadow: 0 10px 40px rgba(0,0,0,0.2);">
            <div class="card-header text-center" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 1rem 1rem 0 0;">
                <h1 class="h3 mb-0" style="color: white; font-weight: 700;">
                    <b>{{ config('app.name') }}</b>
                </h1>
            </div>
            <div class="card-body" style="padding: 2rem;">
                {{ $this->form }}
                
                <div class="row mt-3">
                    <div class="col-12">
                        <x-filament::button
                            type="submit"
                            form="authenticate"
                            class="w-100"
                            style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; padding: 0.75rem; border-radius: 0.75rem; font-weight: 600;"
                        >
                            {{ __('filament-panels::pages/auth/login.form.actions.authenticate.label') }}
                        </x-filament::button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-filament-panels::page.simple>
